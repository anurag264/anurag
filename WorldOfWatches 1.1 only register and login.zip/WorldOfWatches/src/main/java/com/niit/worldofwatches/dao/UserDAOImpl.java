package com.niit.worldofwatches.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.worldofwatches.model.User;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;
	@Transactional
	public List<User> list() {
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) sessionFactory.getCurrentSession()
				.createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;// TODO Auto-generated method stub
		
	}

	public User get(String userid) {
		// TODO Auto-generated method stub
		String hql="from user where userid="+"'"+userid+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<User>list=(List<User>) query.list();
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}
@Transactional
	public void saveOrUpdate(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}
@Transactional
	public void delete(int id) {
		// TODO Auto-generated method stub
	User user=new User();
	user.setId(id);
	sessionFactory.getCurrentSession().delete(user);
		
	}
@Transactional
	public boolean isValidUser(String userid, String password, boolean b) {
	String hql = "from User where userid= '" + userid + "' and " + " password ='" + password + "' and "+" admin='" + b+"'";
	Query query = sessionFactory.getCurrentSession().createQuery(hql);
	
	@SuppressWarnings("unchecked")
	List<User> list = (List<User>) query.list();
	
	if (list != null && !list.isEmpty()) {
		return true;
	}
	
	return false;
	}

}
