package com.niit.worldofwatches.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.niit.worldofwatches.dao.UserDAO;
import com.niit.worldofwatches.model.User;

@Controller
@SessionAttributes("userid")
public class UserController {
@Autowired 
UserDAO userDAO;

@RequestMapping("/isValidUser")
public ModelAndView isValidUser(@RequestParam(value = "name") String userid,
		@RequestParam(value = "password") String password) {
	System.out.println("in controller");

	String message;
	ModelAndView mv ;
	if (userDAO.isValidUser(userid, password,true)) 
	{
		message = "Valid credentials";
		 mv = new ModelAndView("adminHome");
		 mv.addObject("userID", userid);
	}
	else if (userDAO.isValidUser(userid,password,false))
	{
		message = "Valid credentials";
		 mv = new ModelAndView("userHome");
		 mv.addObject("userID", userid);
	}
	
	else {
		message = "Invalid credentials";
		 mv = new ModelAndView("login");
	}

	mv.addObject("message", message);
	mv.addObject("name", userid);
	return mv;
}
@RequestMapping("/register")
public ModelAndView RegPage()  /* controller for viewing the jsp page. this has no relation with the below method */
{
	
	ModelAndView mv = new ModelAndView("register");
	return mv;
}

@RequestMapping("/registeration") /*this name and form action name in register.jsp should be same*/
public ModelAndView registerUser(@ModelAttribute User user) {
	userDAO.saveOrUpdate(user);    /*this method is for registering the user and to insert the details to db*/
	return new ModelAndView("/login");
	
}
@RequestMapping("/login")
public ModelAndView loginPage()  /* controller for viewing the jsp page. this has no relation with the below method */
{
	
	ModelAndView mv = new ModelAndView("login");
	return mv;
}
}