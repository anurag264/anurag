package com.niit.worldofwatches.dao;

import java.util.List;

import com.niit.worldofwatches.model.User;

public interface UserDAO {

	public List<User>list();
	public User get(String userid);
	public void saveOrUpdate(User user);
	public void delete(int id);
	public boolean isValidUser(String userid, String password,boolean b);
}
