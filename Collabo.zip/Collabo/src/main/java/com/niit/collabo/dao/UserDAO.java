package com.niit.collabo.dao;

import com.niit.collabo.model.User;
import java.util.*;

public interface UserDAO {

	public void saveOrUpdate(User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
}
