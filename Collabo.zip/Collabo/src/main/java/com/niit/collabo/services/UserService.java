package com.niit.collabo.services;

import java.util.List;

import com.niit.collabo.model.User;

public interface UserService {
	public void saveOrUpdate(User user);
	public User getUserById(int userid);
	public  List<User> list();
	public User getUserByname(String username);
}
