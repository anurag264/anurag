package com.niit.collabo.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.Date;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.niit.collabo.model.User;
import com.niit.collabo.services.UserService;

@Controller
public class HomeController
{
	
	@Autowired
	UserService userserivce;

	ModelAndView mv;
	
	/*@RequestMapping("/")
	public ModelAndView reg()
	{
		mv = new ModelAndView("Registration");
		return mv;
	}
	*/
	@RequestMapping("/Registration")
	public ModelAndView RegPage()
	{
		mv = new ModelAndView("Registration");
		return mv;
	}
	
	
	
	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("user") User user , Model model,HttpServletRequest request, MultipartFile file) throws IOException
	{
		
		String filename = null;
	    byte[] bytes;
	    
	    		user.setRole("ROLE_USER");
	    		user.setEnabled(true);
	            userserivce.saveOrUpdate(user);
	    		System.out.println("Data Inserted");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		MultipartFile image = user.getImage();
	            //Path path;
	            String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserid()+".jpg");
	            System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image not saved");
	            	}
	            }
	    	
	     	    
	    return "LoginPage";
	
		
	}
	@ModelAttribute("user")
	public  User returnObject()
	{
		return new User();
	}
	

	  
	  @RequestMapping("/")
	   public ModelAndView HomePageapp()
	  {
		  return new  ModelAndView("index");
	  }
	  
		  
}

