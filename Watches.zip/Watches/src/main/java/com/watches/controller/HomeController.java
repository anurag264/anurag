package com.watches.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class HomeController {	
	
	@RequestMapping("/")
	public ModelAndView homePage()
	{
		System.out.println("I am in homepage of controller");
		return new ModelAndView("index");
	}
	
	@RequestMapping("/home")
	public ModelAndView home()
	{
		System.out.println("I am in home controller");
		return new ModelAndView("index");
	}

	@RequestMapping("/aboutus")
	public ModelAndView aboutUs()
	{
		System.out.println("I am in aboutus controller");
		return new ModelAndView("aboutus");
	}
	
	@RequestMapping("/contactus")
	public ModelAndView contactUs()
	{
		System.out.println("I am in contactus controller");
		return new ModelAndView("contactus");
	}
	
	@RequestMapping("/register")
	public ModelAndView register()
	{
		System.out.println("I am in register controller");
		return new ModelAndView("register");
	}
	@RequestMapping("/login")
	public ModelAndView login()
	{
		System.out.println("I am in login controller");
		return new ModelAndView("login");
	}
}
