package com.niit.watches.dao;

import com.niit.watches.model.BillingAddress;

public interface BillingAddressDAO {



public void saveOrUpdate(BillingAddress billingAddress);
}
