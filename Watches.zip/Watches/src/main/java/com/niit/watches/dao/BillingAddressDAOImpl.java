package com.niit.watches.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.watches.model.BillingAddress;

@Repository("billingAddressDAO")
public class BillingAddressDAOImpl implements BillingAddressDAO{
	
	public BillingAddressDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;


	public BillingAddressDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	@Transactional
	public void saveOrUpdate(BillingAddress billingAddress) {
		System.out.println("saveOrUpdate called in BillingAddressDAOImpl");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(billingAddress);
		t.commit();
	}
}