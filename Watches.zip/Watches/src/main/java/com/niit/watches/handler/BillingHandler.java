package com.niit.watches.handler;

import org.springframework.binding.message.MessageBuilder;
import org.springframework.binding.message.MessageContext;
import org.springframework.stereotype.Component;

import com.niit.watches.model.BillingAddress;



@Component
public class BillingHandler {

	public BillingAddress initFlow(){
		return new BillingAddress();
	}

	public String validateDetails(BillingAddress billingAddress,MessageContext messageContext){
		String status = "success";
		
		if(billingAddress.getName().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"name").defaultText("Name cannot be Empty").build());
			status = "failure";
		}
		if(billingAddress.getPincode().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"pincode").defaultText("Pincode cannot be Empty").build());
			status = "failure";
		}
	
		if(billingAddress.getAddress().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"address").defaultText("Address cannot be Empty").build());
			status = "failure";
		}
		if(billingAddress.getLandmark().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"landmark").defaultText("Landmark cannot be Empty").build());
			status = "failure";
		}
		if(billingAddress.getPhone().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"phone").defaultText("Phone cannot be Empty").build());
			status = "failure";
		}
		
		return status;
	}
}
