package com.niit.watches.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {	
	
	@RequestMapping("/")
	public ModelAndView homePage()
	{
	
		return new ModelAndView("index");
	}
	
	@RequestMapping("/home")
	public ModelAndView home()
	{
		
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/homeuser", method = RequestMethod.GET)
	public ModelAndView userHome() 
	{
		
		return new ModelAndView("indexuser");
	}

	@RequestMapping("/aboutus")
	public ModelAndView aboutUs()
	{
		
		return new ModelAndView("aboutus");
	}
	
	@RequestMapping("/contactus")
	public ModelAndView contactUs()
	{
		
		return new ModelAndView("contactus");
	}
	
	@RequestMapping("/nocart")
    public ModelAndView noCart()
    {
		
    	return new ModelAndView("nocart");
    }
	
	@RequestMapping("/register")
	public ModelAndView register()
	{
		
		return new ModelAndView("register");
	}
	
	@RequestMapping("/login")
	public ModelAndView login()
	{
		
		return new ModelAndView("login");
	}

	@RequestMapping("/thankyou")
	public ModelAndView thankYou()
	{
		
		return new ModelAndView("thankyou");
	}
}
