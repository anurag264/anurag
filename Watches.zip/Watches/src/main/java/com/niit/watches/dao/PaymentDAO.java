package com.niit.watches.dao;

import com.niit.watches.model.Payment;

public interface PaymentDAO {

	public void saveOrUpdate(Payment payment);
}
