package com.niit.watches.dao;

public class UserDAO {
	public boolean isValidCredentials(String userID,String password)
	{
		if(userID.equals("NIIT") && password.equals("NIIT@123"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
