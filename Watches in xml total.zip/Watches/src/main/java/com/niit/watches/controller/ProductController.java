package com.niit.watches.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.niit.watches.dao.CategoryDAO;
import com.niit.watches.dao.ProductDAO;
import com.niit.watches.dao.SupplierDAO;
import com.niit.watches.model.Category;
import com.niit.watches.model.Product;
import com.niit.watches.model.Supplier;
import com.niit.watches.util.Util;



@Controller
public class ProductController {

	@Autowired(required=true)
	private ProductDAO productDAO;

	@Autowired(required = true)
	private CategoryDAO categoryDAO;

	@Autowired(required = true)
	private SupplierDAO supplierDAO;

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public String listProducts(Model model) {
		System.out.println("*********listProducts called in ProductController*********");
		model.addAttribute("product", new Product());
		model.addAttribute("category", new Category());
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		return "product";
	}

	// For add and update product both
	@RequestMapping(value = "/product/add", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product product,@RequestParam("file") MultipartFile file,HttpServletRequest request, ModelMap model) {
		System.out.println("*********addProduct called in ProductController*********");
		Util u=new Util();
		String newId=u.replace(product.getId(),",","");
		product.setId(newId);
		Category category = categoryDAO.getByName(product.getCategory().getName());
		categoryDAO.saveOrUpdate(category);  
		Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		supplierDAO.saveOrUpdate(supplier); 
		product.setCategory(category);
		product.setSupplier(supplier);
		product.setCategory_id(category.getId());
		product.setSupplier_id(supplier.getId());
		productDAO.saveOrUpdate(product);
		String name = file.getOriginalFilename();
		String path = "E:\\my own project\\Watches\\src\\main\\webapp\\WEB-INF\\resources\\images";
		if (!file.isEmpty()) {
            try {
            	
            	File imgDirectory = new File(path);
            	if(!imgDirectory.exists())
            	{
            		imgDirectory.mkdir();
            	}
            	
                byte[] bytes = file.getBytes();
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(path+"\\"+name)));
                stream.write(bytes);
                stream.close();
                model.addAttribute("message","You successfully uploaded " + name + " into " + name + "-uploaded !");
                return "redirect:/products";
            } catch (Exception e) {
            	model.addAttribute("message","You failed to upload " + name + " => " + e.getMessage());
            	return "redirect:/products";
            }
        } else {
        	model.addAttribute("message","You failed to upload " + name + " because the file was empty.");
        }
        return "redirect:/products";

	}


	@RequestMapping("product/remove/{id}")
	public String removeProduct(@PathVariable("id") String id, ModelMap model) throws Exception {
		System.out.println("*********removeProduct called in ProductController*********");
		try {
			productDAO.delete(id);
			model.addAttribute("message", "Successfully Deleted");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		return "redirect:/products";
	}

	@RequestMapping("product/edit/{id}")
	public String editProduct(@PathVariable("id") String id, Model model) {
		System.out.println("*********editProduct called in ProductController*********");
		model.addAttribute("product", this.productDAO.get(id));
		model.addAttribute("listProducts", this.productDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
	
		return "product";
	}
	
	@RequestMapping("product/get/{id}")
	public String getSelectedProduct(@PathVariable("id") String id, Model model, RedirectAttributes redirectAttributes) {
		System.out.println("*********getSelectedProduct called in ProductController*********");
		redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
		return "redirect:/productDisplay";
	}
	
	@RequestMapping(value="/productDisplay",method=RequestMethod.GET)
		public String productDisplay(@ModelAttribute("selectProduct") final Object selectedProduct,Model model){
		System.out.println("*********productDisplay called in ProductController*********");
		model.addAttribute("selectProduct",selectedProduct);
		model.addAttribute("categoryList",this.categoryDAO.list());
		return "/productDisplay";
	}
	
	@RequestMapping("product1/get/{id}")
	public String getSelectedProduct1(@PathVariable("id") String id, Model model, RedirectAttributes redirectAttributes) {
		System.out.println("*********getSelectedProduct1 called in ProductController*********");
		redirectAttributes.addFlashAttribute("selectedProduct", productDAO.get(id));
		return "redirect:/productDisplay1";
	}
	
	@RequestMapping(value="/productDisplay1",method=RequestMethod.GET)
		public String productDisplay1(@ModelAttribute("selectProduct") final Object selectedProduct,Model model){
		System.out.println("*********productDisplay1 called in ProductController*********");
		model.addAttribute("selectProduct",selectedProduct);
		model.addAttribute("categoryList",this.categoryDAO.list());
		return "/userHome";
	}
	
}
