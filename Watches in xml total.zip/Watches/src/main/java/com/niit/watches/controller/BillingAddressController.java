package com.niit.watches.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;


import com.niit.watches.dao.BillingAddressDAO;
import com.niit.watches.model.BillingAddress;




@Controller
public class BillingAddressController {
	
	@Autowired
	BillingAddressDAO billingAddressDAO;
	
	public String conformOrder(@ModelAttribute BillingAddress billingAddress) {
		String status="success";
		System.out.println("************conformOrder called in BillingAddressController***********");
		billingAddressDAO.saveOrUpdate(billingAddress);
	   return status;
	 }
	
	
}
