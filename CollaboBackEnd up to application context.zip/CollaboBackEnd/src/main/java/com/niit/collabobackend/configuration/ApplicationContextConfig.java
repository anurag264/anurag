package com.niit.collabobackend.configuration;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan("com.niit.collabobackend")
@EnableTransactionManagement
public class ApplicationContextConfig {
	
	@Bean(name="dataSource")
	public DataSource getOracleDataSource(){
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		dataSource.setDriverClassName("");
		dataSource.setUrl("");
		dataSource.setUsername("");
		dataSource.setPassword("");
		Properties connectionProperties=new Properties();
		connectionProperties.setProperty("","");
		connectionProperties.setProperty("", "");
		connectionProperties.setProperty("","");
		connectionProperties.setProperty("", "");
		dataSource.setConnectionProperties(connectionProperties);
		return dataSource;
		
		
	}
	
	

}
